﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotRightClub.Engine
{
    public enum BoardToken
    {
        ActivationPad,
        RobotStart,
        Obstacle
    }
}
