﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobotRightClub.Engine
{
    public class Player
    {
        public string Name { get; }

        public Player(string name)
        {
            Name = name;
        }
    }
}
