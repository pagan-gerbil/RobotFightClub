﻿namespace RobotRightClub.Engine.BoardActions
{
    public abstract class BoardAction
    {
        internal abstract void Execute(Board board);
    }
}